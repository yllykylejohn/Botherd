from textgenrnn import textgenrnn
import discord
import asyncio
from discord.ext import commands
from collections import defaultdict
import random
import time
textgen = textgenrnn()
bot = commands.Bot(command_prefix='++')
TOKEN = 'NDc5MDAyOTY5OTUwNjUwMzc4.Dqqjmg.aTjfe29rtYJg5B0WAhjnGPSXpW8'
prefix = '++'

client = discord.Client()
@client.event
async def on_message(message):
    try:
        try:
            start_time = time.time()
            if message.author != client.user:
                if not message.content.startswith('=='):
                    if len(message.content) < 1024:
                        if message.channel.id == '498332532702445579' or message.channel.id == '502254053397626891' or message.channel.id == '502718705122279424' or message.channel.id == '532411971866198016':
                            f = open('Database.txt', 'a')
                            f.write(f'{message.content}\n')
                            await client.send_typing(message.channel)
                            fmt = textgen.generate(1, temperature=2.0, return_as_list=True)
                            await client.send_message(message.channel, str(fmt).replace("'",'').replace('[', '').replace(']','') + '\n')
                            with open('Responses.txt', 'a') as ine:
                                ine.write(f'{fmt}\n')
                            with open('Database.txt', 'r+') as f:
                                f.readline()
                                data = f.read()
                                f.seek(0)
                                f.write(data)
                                f.truncate()
                                with open("Database.txt") as fp:
                                    for i, line in enumerate(fp):
                                        if i == 6:
                                            lines = fp.readlines()
                                            lines = lines[:-1]
                                            break
                            print("--- %s seconds ---" % (time.time() - start_time))
                    else:
                        await client.send_message(message.channel, 'The message exceeds the limit')
                elif message.content.startswith('==Clear'):
                    if message.author.id == '399392841308045312':
                        open("Database.txt", "w").close()
                        await client.send_message(message.channel, 'Learning database cleared')
                    else:
                        await client.send_message(message.channel, "You are not Crackhard, cease.")
                        return
                elif message.content.startswith('==learn'):
                    textgen.train_from_file('Database.txt', num_epochs=1)
                    if message.author.id == '399392841308045312':
                        await client.send_message(message.channel, 'Time to roast kids')
                    else:
                        await client.send_message(message.channel, "You are not Crackhard, cease.")
                        return
                else:
                    return
        except (UnicodeEncodeError, AssertionError):
            if message.author != client.user:
                textgen.train_from_file('Database.txt', num_epochs=1)
                fmt = textgen.generate(1, temperature=0.5, return_as_list=True)
                await client.send_message(message.channel, str(fmt).replace("'",'').replace('[', '').replace(']','') + '\n')
                with open('Responses.txt', 'a') as ine:
                    ine.write(f'{fmt}\n')
                with open('Database.txt', 'r+') as f:
                    f.readline()
                    data = f.read()
                    f.seek(0)
                    f.write(data)
                    f.truncate()
                    with open("Database.txt") as fp:
                        for i, line in enumerate(fp):
                            if i == 6:
                                lines = fp.readlines()
                                lines = lines[:-1]
                                break

    except Exception:
        await client.send_message(532411971866198016, 'Cum coma')
        import Anotherone
        print('AY IT CRASHED BUT WE ALL AIT')
            

async def on_ready():
    textgen.train_from_file('Database.txt', num_epochs=2)
    print('works')
    change_status(game='Am i cracc?')


client.run(TOKEN)

