import subprocess
subprocess.call([r'Reset-self.bat'])
