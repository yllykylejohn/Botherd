import random
import math

import operator
from PIL import Image, ImageDraw, ImageColor
class HGplayer:

    def __init__(self, username, hp):
        self.name = username
        self.weapon = []
        self.apparel = []
        self.inventory = []
        self.health = hp
        self.location = []
        self.dead = False


    def add_weapon(self, weapon):
        self.weapon.append(weapon)

    def remove_weapon(self, weapon):
        try:
            self.weapon.remove(weapon)
        except:
            print('Error no item of that name is in the list')

    def add_apparel(self, apparel):
        self.apparel.append(apparel)

    def remove_apparel(self, apparel):
        try:
            self.apparel.remove(apparel)
        except:
            print('Error no item of that name is in the list')

    def add_inventory(self, inventory):
        self.inventory.append(inventory)

    def remove_inventory(self, inventory):
        try:
            self.inventory.remove(inventory)
        except:
            print('Error no item of that name is in the list')

    def set_health(self, hp):
        try:
            self.health = hp
        except:
            print('Error non-integer defined')

    def add_health(self, hp):
        try:
            self.health += hp
        except:
            print('Error non-integer defined')

    def sub_health(self, hp):
        try:
            self.health += operator.neg(hp)
        except:
            print('Error non-integer defined')

    def location_set(self, x, y):
        try:
            xy = [(x, y), (x+10, y+10)]
            self.location = xy
        except:
            print("Error non-integer(s) defined")

    def kill(self):
        self.dead = True
        return self.dead

step = True
##todo add body parts
xx = 250
yy = 250
peeps = ['cracc',
         'bruh']
cracc = HGplayer('cracc', 100)
bruh = HGplayer('bruh', 100)

while step == True:
    for peep in peeps:
        xx += random.randint(-20, 20)
        yy += random.randint(-20, 20)
        cracc.location_set(xx, yy)


    minimap = Image.open('minimap/MAP.png')
    minimap_players = Image.new('RGBA', minimap.size, (255, 255, 255,0))
    for peep in peeps:

        xy = peep.location
        col = ImageColor.getrgb('red')
        minimap_players_d = ImageDraw.Draw(minimap_players)
        minimap_players_d.ellipse(peep.location, col, '#ffffff', 2)
        hhh = Image.alpha_composite(minimap, minimap_players)
        hhh.show()
    if input('y for step') != 'y':
        step = False



