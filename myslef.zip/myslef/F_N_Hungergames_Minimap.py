from PIL import Image, ImageDraw, ImageColor
import F_N_Hungergames_Humans


cracc = F_N_Hungergames_Humans.HGplayer('cracc', 100)

minimap = Image.open('minimap/MAP.png')

minimap_players = Image.new('RGBA', minimap.size, (255, 255, 255,0))

col = ImageColor.getrgb('red')
minimap_players_d = ImageDraw.Draw(minimap_players)
minimap_players_d.ellipse(xy, col, '#ffffff', 2)
hhh = Image.alpha_composite(map, minimap_players)
hhh.show()