import textgenrnn
import discord
import tensorflow
import asyncio
from discord.ext import commands
from collections import defaultdict
import random
import time
textgen = textgenrnn()
bot = commands.Bot(command_prefix='++')
TOKEN = 'NDQ1NzE5Njc5NjkyOTYzODQx.DpqYyg.ZxFnQ2gWgDAVtaNc8BLSBPP9MLw'
prefix = '++'

client = discord.Client()
@client.event
async def on_message(message):
    try:
        start_time = time.time()
        if message.author != client.user:
            if not message.content.startswith('=='):
                if len(message.content) < 1024:
                    if message.channel.id == '498332532702445579' or message.channel.id == '502254053397626891' or message.channel.id == '502718705122279424' or message.channel.id == '532411971866198016':
                        f = open('Database.txt', 'a')
                        f.write(f'{message.content}\n')
                        await client.send_typing(message.channel)
                        textgen.train_from_file('Database.txt', num_epochs=1)
                        fmt = textgen.generate(1, temperature=2.0, return_as_list=True)
                        await client.send_message(message.channel, str(fmt).replace("'",'').replace('[', '').replace(']','') + '\n')
                        with open('Responses.txt', 'a') as ine:
                            ine.write(f'{fmt}\n')
                        with open('Database.txt', 'r+') as f:
                            f.readline()
                            data = f.read()
                            f.seek(0)
                            f.write(data)
                            f.truncate()
                            with open("Database.txt") as fp:
                                for i, line in enumerate(fp):
                                    if i == 6:
                                        lines = fp.readlines()
                                        lines = lines[:-1]
                                        break
                        print("--- %s seconds ---" % (time.time() - start_time))
                else:
                    await client.send_message(message.channel, 'The message exceeds the limit')
            elif message.content.startswith('==Clear'):
                if message.author.id == '399392841308045312':
                    open("Database.txt", "w").close()
                    await client.send_message(message.channel, 'Learning database cleared')
                else:
                    await client.send_message(message.channel, "You are not Crackhard, cease.")
                    return
            elif message.content.startswith('==555'):
                print(message.author)
                if message.author.id == '399392841308045312':
                    await client.send_message(message.channel, 'Time to roast kids')
                else:
                    await client.send_message(message.channel, "You are not Crackhard, cease.")
                    return
            else:
                return
    except (UnicodeEncodeError, AssertionError):
        return



async def wait_until_ready():
    print('works')
    change_status(game='I am back and running')


client.run(TOKEN)
