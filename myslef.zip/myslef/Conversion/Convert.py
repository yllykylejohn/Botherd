import fileinput
with open('input.txt', 'r') as inp:
    with open('output.txt', 'w') as outp:
         lev = input('What would you like to detect: ')
         ent = input('What would you like to replace with: ')
         output = inp.read().replace(lev, ent)
         outp.write(output)
         print('Converted text into output')
